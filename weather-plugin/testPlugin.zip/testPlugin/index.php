<?php
// silance is golden
<h1>Weather </h1>
<br>
<br>

<section class="pd-weather-plu-sec">

    <input id="city" value="" />
    <button id="getWeatherForcast2"> Check Weather</button>
    <div id="showWeatherForcastfrm"></div>

    <script>
        $(document).ready(function() {
            $("#getWeatherForcast2").click(function() {
                var city = $("#city").val();
                var key = "8e0addc5aa27fafb746fb228f42df6b5";

                $.ajax({
                    url: 'http://api.openweathermap.org/data/2.5/weather',
                    dataType: 'json',
                    type: 'GET',
                    data: {
                        q: city,
                        appid: key,
                        units: 'metric'
                    },

                    success: function(data) {
                        var wf = '';
                        $.each(data.weather, function(index, val) {
                            wf +=
                                '<br><form id="weather_form_subm" method="post" action="#"><input name="country" value="' + data.name + '"><br><br><input name="temp" value="' + data.main.temp + '"&deg;C ><br><br><input name="desc" value="' + val.main + '"><button type="submit">Save</button></form>'
                        });
                        $("#showWeatherForcastfrm").html(wf);
                    }

                })

            });
        });
    </script>


    <?php
    global $wpdb;
    $firstName = $_POST["country"];

    $wpdb->insert('wp_plg', array(
        'weather_location' => $firstName,
    ));
    ?>

</section>

<!-- ============ saved weather section ============= -->
<br>
<br>
<hr>
<br>
<section class="pd-saved_weather">

    <?php
    // $post_id = $wpdb->get_results("SELECT * FROM $wpdb->wp_plg ");
    global $wpdb;

    $results = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . $wpdb->prefix . 'plg'));

    foreach ($results as $r) {
        $item_id = $r->id;
        $country = $r->weather_location;


    ?>


        <input type="hidden" id="city<?php echo $item_id;  ?>" value="<?php echo $country;  ?>" />
        <input type="hidden" id="pid<?php echo $item_id; ?>" value="<?php echo $item_id;  ?>" />

        <div style=" display:inline-block;">

            <form id="deleteForm<?php echo $item_id; ?>" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <button type="submit" id="deleteBtn<?php echo $item_id; ?>">Delete </button>
                <input type="hidden" name="deleteID<?php echo $item_id; ?>" id="pid<?php echo $item_id; ?>" value="<?php echo $item_id;  ?>" />

                <?php
                global $wpdb;
                $id = $_POST['deleteID'];
                $table = 'wp_plg';
                $wpdb->delete($table, array('id' => $id));


                ?>
                <script>
                    $(document).ready(function() {
                        $("#deleteBtn<?php echo $item_id; ?>").click(function(event) {
                            event.preventDefault();
                            var city = $("#pid<?php echo $item_id; ?>").val();

                            $.ajax({
                            url: '',
                            dataType: '',
                            type: 'POST',
                            data: {
                                deleteID: city
                            },
                            success: function () {
                                $('#showWeatherCard<?php echo $item_id; ?>').fadeOut();
                                $('#deleteForm<?php echo $item_id; ?>').fadeOut();

                            }
                                    

                        });
                        });
                    });
                </script>





            </form>
        </div>


        <div class="pd-sec-rel-weather" id="showWeatherCard<?php echo $item_id; ?>" style="text-align: center;
                        margin: 15px;
                        box-shadow: 0px 0px 7px #0000002b;
                        padding: 15px;
                        width:25%;
                        display:inline-block;
                        ">


        </div>

        <script>
            // ========================================================

            $(document).ready(function() {
                var city = $("#city<?php echo $item_id;  ?>").val();
                var pid = $("#pid<?php echo $item_id;  ?>").val();
                var htmlele = $("#pid<?php echo $item_id;  ?>").val();
                var key = "8e0addc5aa27fafb746fb228f42df6b5";

                $.ajax({
                    url: 'http://api.openweathermap.org/data/2.5/weather',
                    dataType: 'json',
                    type: 'GET',
                    data: {
                        q: city,
                        appid: key,
                        units: 'metric'
                    },

                    success: function(data) {
                        var htmlele = '';
                        $.each(data.weather, function(index, val) {
                            htmlele += '<p><b>' + data.name + "</b><img src=//openweathermap.org/themes/openweathermap/assets/vendor/owm/img/widgets/" + val.icon + ".png></p>" + data.main.temp + '&deg;C' + ' | ' + val.main

                        });
                        $("#showWeatherCard" + pid).html(htmlele);
                    }

                })


            });
        </script>
    <?php
    }
    ?>
</section>
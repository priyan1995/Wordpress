<?php

/**
 * Plugin Name:       Test Plugin
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Handle the basics with this plugin. 
 * Requires PHP:      7.2
 * Author:            Priyan Darshana
 
 */

?>

<?php

if (!defined('ABSPATH')) exit;


require_once(dirname(__FILE__) . '/function.php');




// ////////////// weather plugin class

class WeatherPlugin
{
    public $plugin;


    function __construct()
    {
        $this->plugin =  plugin_basename(__FILE__);
        add_action('init', array($this, 'custom_post_type'));
    }

    // register styles
    function register()
    {
        add_action('wp_enqueue_scripts', array($this, 'enqueue'));

        add_action('admin_menu', array($this, 'add_admin_pages'));       
    }

    public function add_admin_pages()
    {
        // admin panel  plugin page creation
        add_menu_page('Weather Plugin', 'Weather ', 'manage_options', 'pd_weather', array($this, 'admin_index'), 'dashicons-cloud', 110);
    }

    public function admin_index()
    {
        // weather plugin page include
        require_once plugin_dir_path(__FILE__) . 'templates/admin.php';
    }

    function activate()
    {
        // generate cpt
        $this->custom_post_type();
        // flush reqrite rules
        flush_rewrite_rules();
    }

    function deactivate()
    {
    }

    function uninstall()
    {
    }

    function custom_post_type()
    {
        register_post_type('weather', ['public' => true, 'label' => 'Custom Weather', 'menu_icon' => 'dashicons-admin-site-alt3']);
    }

    function enqueue()
    {
        wp_enqueue_style('pluginStyle', plugins_url('/style.css', __FILE__));
    }

    //Table Generating code when plugin activate
    function custom_plugin_tables()
    {

        global $wpdb;

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

        if (count($wpdb->get_var('SHOW TABLES LIKE "wp_plg"')) == 0) {

            $sql_query_to_create_table = "CREATE TABLE `wp_plg` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `weather_location` varchar(255) NOT NULL,
                PRIMARY KEY (`id`)
               ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

            dbDelta($sql_query_to_create_table);
        }
    }
}

if (class_exists('WeatherPlugin')) {
    $weather_plugin = new WeatherPlugin();
    //style call    
    $weather_plugin->register();
    // $weather_plugin->custom_plugin_tables();
}

// activation 
register_activation_hook(__FILE__, array($weather_plugin,'custom_plugin_tables'));


// deactivation 
register_deactivation_hook(__FILE__, array($weather_plugin, 'deactivate'));




// add_action( 'init', 'function_name' );

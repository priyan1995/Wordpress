<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>


<?php

// /////// widget area
function wpb_load_widget_area()
{
    register_sidebar(array(
        'name' => __('Add-Page', 'wpb'),
        'id' => 'test-plug',
        'description' => __('', 'wpb'),
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));
    // register_widget('wpb_widget');
}
add_action('widgets_init', 'wpb_load_widget_area');


// Register and load the widget
function wpb_load_widget()
{
    register_widget('wpb_widget');
}
add_action('widgets_init', 'wpb_load_widget');


// Creating the widget 
class wpb_widget extends WP_Widget
{
    function __construct()
    {
        parent::__construct(

            // Base ID of your widget
            'wpb_widget',

            // Widget name will appear in UI
            __('Weather Widget', 'wpb_widget_domain'),

            // Widget description
            array('description' => __('Weather widget for Test Plugin', 'wpb_widget_domain'),)
        );
    }

    // Creating widget front-end

    public function widget($args, $instance)
    {
        $location = apply_filters('widget_location', $instance['location']);
        $title = apply_filters('widget_title', $instance['title']);

        // This is where you run the code and display the output
?>
        <section class="pd-weather-plu-sec">
            <?php
            // before and after widget arguments are defined by themes
            echo $args['before_widget'];
            if (!empty($title))
                //echo $args['before_title'] . $title . $args['after_title'];
            ?>

            <input id="city" value="<?php echo $instance['location']; ?>" />
            <button id="getWeatherForcast"> Check Weather</button>
            <div id="showWeatherForcast"></div>


            <script>
                $(document).ready(function() {
                    $("#getWeatherForcast").click(function() {
                        var city = $("#city").val();
                        var key = "8e0addc5aa27fafb746fb228f42df6b5";

                        $.ajax({
                            url: 'http://api.openweathermap.org/data/2.5/weather',
                            dataType: 'json',
                            type: 'GET',
                            data: {
                                q: city,
                                appid: key,
                                units: 'metric'
                            },

                            success: function(data) {
                                var wf = '';
                                $.each(data.weather, function(index, val) {
                                    wf += '<br><p><b>' + data.name + "</b></p><img src=//openweathermap.org/themes/openweathermap/assets/vendor/owm/img/widgets/" + val.icon + ".png> <p>" + data.main.temp + '&deg;C' + ' | ' + val.main + '</p>'
                                });
                                $("#showWeatherForcast").html(wf);
                            }

                        })

                    });
                });
            </script>
        </section>

    <?php

        echo $args['after_widget'];
    }

    // Widget Backend 
    public function form($instance)
    {
        if (isset($instance['title'])) {
            $title = $instance['title'];
            $location = $instance['location'];
        } else {
            $title = __('Check Your Weather', 'wpb_widget_domain');
        }

        $title = __($instance['title'], 'wpb_widget_domain');
        $location = __($instance['location'], 'wpb_widget_domain');
        // Widget admin form
    ?>

        <!-- title -->
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
                <?php _e('Title:'); ?>
            </label>

            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>

        <!-- Location -->
        <p>
            <label for="<?php echo $this->get_field_id('location'); ?>">
                <?php _e('Location:'); ?>
            </label>

            <input class="widefat" id="<?php echo $this->get_field_id('location'); ?>" name="<?php echo $this->get_field_name('location'); ?>" type="text" value="<?php echo esc_attr($location); ?>" />
        </p>




    <?php
    }

    // Updating widget replacing old instances with new
    public function update($new_instance, $old_instance)
    {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['location'] = (!empty($new_instance['location'])) ? strip_tags($new_instance['location']) : '';
        return $instance;
    }
} // Class wpb_widget ends here


// widget callback function frontend->dynamic_sidebar( 'test-plug' );


//////////////////////////////////////////////////////////// backend selected weather detailes 

function relatedWheather()
{
    ?>
    <section style=" padding: 5%;background: #caefe6;">
    <h2>Local Weather</h2>
        <?php
        $weatherc = new WP_Query(array('orderby' => 'date', 'post_type' => 'weather', 'order' => 'DESC', 'showposts' => ''));
        if ($weatherc->have_posts()) :
            while ($weatherc->have_posts()) :
                $weatherc->the_post();
        ?>


                <input type="hidden" id="city<?php echo get_the_id(); ?>" value="<?php the_title(); ?>" />
                <input type="hidden" id="pid<?php echo get_the_id(); ?>" value="<?php echo get_the_id(); ?>" />
                <div class="pd-sec-rel-weather" id="showWeatherCard<?php echo get_the_id(); ?>" style="text-align: center;
                        margin: 15px;
                        box-shadow: 0px 0px 7px #0000002b;
                        padding: 15px;
                        width:25%;
                        display:inline-block;
                        "></div>

                <script>
                    $(document).ready(function() {
                        var city = $("#city<?php echo get_the_id(); ?>").val();
                        var pid = $("#pid<?php echo get_the_id(); ?>").val();
                        var htmlele = $("#pid<?php echo get_the_id(); ?>").val();
                        var key = "8e0addc5aa27fafb746fb228f42df6b5";

                        $.ajax({
                            url: 'http://api.openweathermap.org/data/2.5/weather',
                            dataType: 'json',
                            type: 'GET',
                            data: {
                                q: city,
                                appid: key,
                                units: 'metric'
                            },

                            success: function(data) {
                                var htmlele = '';
                                $.each(data.weather, function(index, val) {
                                    htmlele += '<p><b>' + data.name + "</b><img src=//openweathermap.org/themes/openweathermap/assets/vendor/owm/img/widgets/" + val.icon + ".png></p>" + data.main.temp + '&deg;C' + ' | ' + val.main

                                });
                                $("#showWeatherCard" + pid).html(htmlele);
                            }

                        })


                    });
                </script>
    <?php
            endwhile;
        endif;
        wp_reset_query();
    }
    ?>
    </section> <?php

                add_shortcode('weather', 'relatedWheather');

// ----- weather worldwide function
   function relatedWheather_ww()
                {
     ?>
        <div style=" padding: 5%;background: #0037ff14;">
            <h2>Weather Worldwide</h2>

            <?php
                    global $wpdb;
                    $results = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . $wpdb->prefix . 'plg'));
                    foreach ($results as $r) {
                        $item_id = $r->id;
                        $country = $r->weather_location;

            ?>


                <input type="hidden" id="cityww<?php echo $item_id;  ?>" value="<?php echo $country; ?>" />
                <input type="hidden" id="pidww<?php echo $item_id; ?>" value="<?php echo $item_id; ?>" />
                <div class="pd-sec-rel-weather" id="showWeatherCardww<?php echo $item_id; ?>" style="text-align: center;
                        margin: 15px;
                        box-shadow: 0px 0px 7px #0000002b;
                        padding: 15px;
                        width:25%;
                        display:inline-block;
                        "></div>

                <script>
                    $(document).ready(function() {
                        var city = $("#cityww<?php echo $item_id; ?>").val();
                        var pid = $("#pidww<?php echo $item_id; ?>").val();
                        var htmlele = $("#pidww<?php echo $item_id; ?>").val();
                        var key = "8e0addc5aa27fafb746fb228f42df6b5";

                        $.ajax({
                            url: 'http://api.openweathermap.org/data/2.5/weather',
                            dataType: 'json',
                            type: 'GET',
                            data: {
                                q: city,
                                appid: key,
                                units: 'metric'
                            },

                            success: function(data) {
                                var htmlele = '';
                                $.each(data.weather, function(index, val) {
                                    htmlele += '<p><b>' + data.name + "</b><img src=//openweathermap.org/themes/openweathermap/assets/vendor/owm/img/widgets/" + val.icon + ".png></p>" + data.main.temp + '&deg;C' + ' | ' + val.main

                                });
                                $("#showWeatherCardww" + pid).html(htmlele);
                            }
                        })
                    });
                </script>
            <?php   }    ?>
        </div>
    <?php } ?>
    <?php

    add_shortcode('weather-ww', 'relatedWheather_ww');


    
